﻿namespace Hache_Jacob_Assignment2_Client
{
    partial class frmClientDrawing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUp = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnLeft = new System.Windows.Forms.Button();
            this.btnRight = new System.Windows.Forms.Button();
            this.txtIP = new System.Windows.Forms.TextBox();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.lblIP = new System.Windows.Forms.Label();
            this.lblPort = new System.Windows.Forms.Label();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnDraw = new System.Windows.Forms.Button();
            this.lblDefaultIP = new System.Windows.Forms.Label();
            this.lblDefaultPort = new System.Windows.Forms.Label();
            this.txtLineLength = new System.Windows.Forms.TextBox();
            this.lblLineLength = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.rbtnYellow = new System.Windows.Forms.RadioButton();
            this.rbtnGreen = new System.Windows.Forms.RadioButton();
            this.rbtnRed = new System.Windows.Forms.RadioButton();
            this.rbtnBlue = new System.Windows.Forms.RadioButton();
            this.rbtnBlack = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // btnUp
            // 
            this.btnUp.Location = new System.Drawing.Point(74, 245);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(60, 40);
            this.btnUp.TabIndex = 0;
            this.btnUp.Text = "Up";
            this.btnUp.UseVisualStyleBackColor = true;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnDown
            // 
            this.btnDown.Location = new System.Drawing.Point(74, 325);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(60, 40);
            this.btnDown.TabIndex = 1;
            this.btnDown.Text = "Down";
            this.btnDown.UseVisualStyleBackColor = true;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnLeft
            // 
            this.btnLeft.Location = new System.Drawing.Point(14, 285);
            this.btnLeft.Name = "btnLeft";
            this.btnLeft.Size = new System.Drawing.Size(60, 40);
            this.btnLeft.TabIndex = 2;
            this.btnLeft.Text = "Left";
            this.btnLeft.UseVisualStyleBackColor = true;
            this.btnLeft.Click += new System.EventHandler(this.btnLeft_Click);
            // 
            // btnRight
            // 
            this.btnRight.Location = new System.Drawing.Point(134, 285);
            this.btnRight.Name = "btnRight";
            this.btnRight.Size = new System.Drawing.Size(60, 40);
            this.btnRight.TabIndex = 3;
            this.btnRight.Text = "Right";
            this.btnRight.UseVisualStyleBackColor = true;
            this.btnRight.Click += new System.EventHandler(this.btnRight_Click);
            // 
            // txtIP
            // 
            this.txtIP.Location = new System.Drawing.Point(698, 360);
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new System.Drawing.Size(90, 20);
            this.txtIP.TabIndex = 4;
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(698, 420);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(90, 20);
            this.txtPort.TabIndex = 5;
            // 
            // lblIP
            // 
            this.lblIP.Location = new System.Drawing.Point(697, 339);
            this.lblIP.Name = "lblIP";
            this.lblIP.Size = new System.Drawing.Size(90, 15);
            this.lblIP.TabIndex = 6;
            this.lblIP.Text = "IP Address:";
            this.lblIP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPort
            // 
            this.lblPort.Location = new System.Drawing.Point(697, 400);
            this.lblPort.Name = "lblPort";
            this.lblPort.Size = new System.Drawing.Size(90, 15);
            this.lblPort.TabIndex = 7;
            this.lblPort.Text = "Server Port:";
            this.lblPort.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(698, 465);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(90, 50);
            this.btnConnect.TabIndex = 8;
            this.btnConnect.Text = "Check Connection";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(64, 450);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(80, 60);
            this.btnClear.TabIndex = 9;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDraw
            // 
            this.btnDraw.Location = new System.Drawing.Point(64, 377);
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(80, 60);
            this.btnDraw.TabIndex = 10;
            this.btnDraw.Text = "Draw";
            this.btnDraw.UseVisualStyleBackColor = true;
            this.btnDraw.Click += new System.EventHandler(this.btnDraw_Click);
            // 
            // lblDefaultIP
            // 
            this.lblDefaultIP.Location = new System.Drawing.Point(587, 359);
            this.lblDefaultIP.Name = "lblDefaultIP";
            this.lblDefaultIP.Size = new System.Drawing.Size(105, 20);
            this.lblDefaultIP.TabIndex = 11;
            this.lblDefaultIP.Text = "Default: 127.0.0.1";
            this.lblDefaultIP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDefaultPort
            // 
            this.lblDefaultPort.Location = new System.Drawing.Point(590, 419);
            this.lblDefaultPort.Name = "lblDefaultPort";
            this.lblDefaultPort.Size = new System.Drawing.Size(105, 20);
            this.lblDefaultPort.TabIndex = 12;
            this.lblDefaultPort.Text = "Default: 5000";
            this.lblDefaultPort.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtLineLength
            // 
            this.txtLineLength.Location = new System.Drawing.Point(223, 481);
            this.txtLineLength.Name = "txtLineLength";
            this.txtLineLength.Size = new System.Drawing.Size(91, 20);
            this.txtLineLength.TabIndex = 13;
            // 
            // lblLineLength
            // 
            this.lblLineLength.Location = new System.Drawing.Point(223, 465);
            this.lblLineLength.Name = "lblLineLength";
            this.lblLineLength.Size = new System.Drawing.Size(91, 13);
            this.lblLineLength.TabIndex = 14;
            this.lblLineLength.Text = "Line Length";
            this.lblLineLength.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(156, 482);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 17);
            this.label1.TabIndex = 15;
            this.label1.Text = "Default: 20";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rbtnYellow
            // 
            this.rbtnYellow.Location = new System.Drawing.Point(35, 75);
            this.rbtnYellow.Name = "rbtnYellow";
            this.rbtnYellow.Size = new System.Drawing.Size(104, 24);
            this.rbtnYellow.TabIndex = 16;
            this.rbtnYellow.TabStop = true;
            this.rbtnYellow.Text = "Yellow";
            this.rbtnYellow.UseVisualStyleBackColor = true;
            this.rbtnYellow.CheckedChanged += new System.EventHandler(this.rbtnYellow_CheckedChanged);
            // 
            // rbtnGreen
            // 
            this.rbtnGreen.Location = new System.Drawing.Point(35, 105);
            this.rbtnGreen.Name = "rbtnGreen";
            this.rbtnGreen.Size = new System.Drawing.Size(104, 24);
            this.rbtnGreen.TabIndex = 17;
            this.rbtnGreen.TabStop = true;
            this.rbtnGreen.Text = "Green";
            this.rbtnGreen.UseVisualStyleBackColor = true;
            this.rbtnGreen.CheckedChanged += new System.EventHandler(this.rbtnGreen_CheckedChanged);
            // 
            // rbtnRed
            // 
            this.rbtnRed.Location = new System.Drawing.Point(35, 135);
            this.rbtnRed.Name = "rbtnRed";
            this.rbtnRed.Size = new System.Drawing.Size(104, 24);
            this.rbtnRed.TabIndex = 18;
            this.rbtnRed.TabStop = true;
            this.rbtnRed.Text = "Red";
            this.rbtnRed.UseVisualStyleBackColor = true;
            this.rbtnRed.CheckedChanged += new System.EventHandler(this.rbtnRed_CheckedChanged);
            // 
            // rbtnBlue
            // 
            this.rbtnBlue.Location = new System.Drawing.Point(35, 163);
            this.rbtnBlue.Name = "rbtnBlue";
            this.rbtnBlue.Size = new System.Drawing.Size(104, 24);
            this.rbtnBlue.TabIndex = 19;
            this.rbtnBlue.TabStop = true;
            this.rbtnBlue.Text = "Blue";
            this.rbtnBlue.UseVisualStyleBackColor = true;
            this.rbtnBlue.CheckedChanged += new System.EventHandler(this.rbtnBlue_CheckedChanged);
            // 
            // rbtnBlack
            // 
            this.rbtnBlack.Location = new System.Drawing.Point(35, 193);
            this.rbtnBlack.Name = "rbtnBlack";
            this.rbtnBlack.Size = new System.Drawing.Size(104, 24);
            this.rbtnBlack.TabIndex = 20;
            this.rbtnBlack.TabStop = true;
            this.rbtnBlack.Text = "Black";
            this.rbtnBlack.UseVisualStyleBackColor = true;
            this.rbtnBlack.CheckedChanged += new System.EventHandler(this.rbtnBlack_CheckedChanged);
            // 
            // frmClientDrawing
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 527);
            this.Controls.Add(this.rbtnBlack);
            this.Controls.Add(this.rbtnBlue);
            this.Controls.Add(this.rbtnRed);
            this.Controls.Add(this.rbtnGreen);
            this.Controls.Add(this.rbtnYellow);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblLineLength);
            this.Controls.Add(this.txtLineLength);
            this.Controls.Add(this.lblDefaultPort);
            this.Controls.Add(this.lblDefaultIP);
            this.Controls.Add(this.btnDraw);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.lblPort);
            this.Controls.Add(this.lblIP);
            this.Controls.Add(this.txtPort);
            this.Controls.Add(this.txtIP);
            this.Controls.Add(this.btnRight);
            this.Controls.Add(this.btnLeft);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnUp);
            this.Name = "frmClientDrawing";
            this.Text = "Etch A Sketch";
            this.Load += new System.EventHandler(this.frmClientDrawing_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnLeft;
        private System.Windows.Forms.Button btnRight;
        private System.Windows.Forms.TextBox txtIP;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.Label lblIP;
        private System.Windows.Forms.Label lblPort;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnDraw;
        private System.Windows.Forms.Label lblDefaultIP;
        private System.Windows.Forms.Label lblDefaultPort;
        private System.Windows.Forms.TextBox txtLineLength;
        private System.Windows.Forms.Label lblLineLength;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbtnYellow;
        private System.Windows.Forms.RadioButton rbtnGreen;
        private System.Windows.Forms.RadioButton rbtnRed;
        private System.Windows.Forms.RadioButton rbtnBlue;
        private System.Windows.Forms.RadioButton rbtnBlack;
    }
}

