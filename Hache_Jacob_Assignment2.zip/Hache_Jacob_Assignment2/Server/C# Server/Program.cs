﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MultiClientServer
{
    class Program
    {
        private static TcpListener _server;
        private static bool _isRunning;

        private static List<string> drawX = new List<string>();
        private static List<string> drawY = new List<string>();

        static void Main(string[] args)
        {
            // Initialize server
            _server = new TcpListener(IPAddress.Any, 5000);
            _server.Start();

            _isRunning = true;
            Console.WriteLine("Server started on port 5000...");

            // Start accepting clients
            Task.Run(() => AcceptClientsAsync());

            // Keep the server running
            Console.ReadLine();
        }

        private static async Task AcceptClientsAsync()
        {
            while (_isRunning)
            {
                // Accept a new client
                var client = await _server.AcceptTcpClientAsync();
                Console.WriteLine("New client connected.");

                

                // Handle client connection in a separate task
                Task.Run(() => HandleClientAsync(client));
            }
        }


     

        private static async Task HandleClientAsync(TcpClient client)
        {

            

            try
            {
                using (NetworkStream stream = client.GetStream())
                using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                using (StreamWriter writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true })
                {
                    // Send a welcome message
                    //await writer.WriteLineAsync("You made it, congrats");

                    string clientMessage;
                    // Read messages from the client
                    while ((clientMessage = await reader.ReadLineAsync()) != null)
                    {
                        Console.WriteLine($"Received: {clientMessage}");


                        if (clientMessage.Contains("DRAW"))
                        {
                            clientMessage = await reader.ReadLineAsync();

                            await writer.WriteLineAsync(drawX.Count.ToString());

                            for (int counter = 0; counter < drawX.Count; counter++)
                            {

                                await writer.WriteLineAsync($"{drawX[counter].ToString()}");
                                await writer.WriteLineAsync($"{drawY[counter].ToString()}");


                            }

                        }
                        else if (clientMessage.Contains("Hello!"))
                        {

                            clientMessage += await reader.ReadLineAsync();

                        }
                        else if (clientMessage.Contains("CLEAR"))
                        {

                            drawX.Clear();
                            drawY.Clear();
                            Console.WriteLine(drawX.Count + ", " + drawY.Count);
                            Console.WriteLine("List Cleared.");
                            clientMessage += await reader.ReadLineAsync();

                        }
                        else if (clientMessage != "Hello!")
                        {

                            drawX.Add(clientMessage);

                            clientMessage = await reader.ReadLineAsync();

                            Console.WriteLine($"Received: {clientMessage}");

                            drawY.Add(clientMessage);

                            Console.WriteLine(drawX.Count + ", " + drawY.Count);


                        }
                        



                        // Echo the message back to the client
                        await writer.WriteLineAsync($"Server Echo: {clientMessage}");

                        
                            break;
                        
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                Console.WriteLine("Client disconnected.");
                client.Close();
            }

            

        }

    }
}

