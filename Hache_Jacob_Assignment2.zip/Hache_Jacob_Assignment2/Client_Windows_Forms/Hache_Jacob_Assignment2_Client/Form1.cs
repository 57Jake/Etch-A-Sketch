﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hache_Jacob_Assignment2_Client
{
    public partial class frmClientDrawing : Form
    {
        private static string direction;

        private static int x = 200;
        private static int y = 200;
        private static int step = 20;
        private static Graphics EtchASketch;
        private static Pen pen = new Pen(Color.Black, 2);

        private static bool connectionOK = false;

        private string xToSend, yToSend;

        private static int xToDraw, yToDraw;

        private List<int> xList = new List<int>();
        private List<int> yList = new List<int>();

        public frmClientDrawing()
        {
            InitializeComponent();
            EtchASketch = this.CreateGraphics();
            
            
            

        }



        private void frmClientDrawing_Load(object sender, EventArgs e)
        {

            EtchASketch.Clear(Color.White);

        }


        

        private void btnConnect_Click(object sender, EventArgs e)
        {

            try
            {

                string serverIp = txtIP.Text;
                if (string.IsNullOrEmpty(serverIp)) serverIp = "127.0.0.1";

                string serverPort = txtPort.Text;
                int port = string.IsNullOrEmpty(serverPort) ? 5000 : int.Parse(serverPort);

                connectToServer(serverIp, port, "Hello!", "Hello!", "No Direction");

                btnClear.Enabled = true;

            }
            catch(Exception ex)
            {

                MessageBox.Show(ex.ToString());

            }

            

        }

        

        static async Task connectToServer(string passedIP, int passedPort, string passedX, string passedY, string passedDirection)
        {

            

            //MessageBox.Show(passedIP + ", " + passedPort);

            try
            {
                // Connect to the server
                using (TcpClient client = new TcpClient())
                {
                    
                    await client.ConnectAsync(passedIP, passedPort);

                   
                    

                        

                    
                    

                    using (NetworkStream stream = client.GetStream())
                    using (StreamReader reader = new StreamReader(stream, Encoding.UTF8))
                    using (StreamWriter writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true })
                    {
                        // Receive the welcome message from the server
                        //string welcomeMessage = await reader.ReadLineAsync();
                        //MessageBox.Show($"Server: {welcomeMessage}");

                        //send messages to the server
                        await writer.WriteLineAsync(passedX);
                        await writer.WriteLineAsync(passedY);
                        

                        string welcomeMessage = await reader.ReadLineAsync();
                        //MessageBox.Show($"It Sent back: {welcomeMessage}");

                        if (passedX == "Hello!")
                        {

                            MessageBox.Show("Connection is ok, you can draw now!");
                            welcomeMessage = await reader.ReadLineAsync();
                            connectionOK = true;

                        }
                        else if (passedX == "DRAW")
                        {

                            int numberOfLines = int.Parse(welcomeMessage);

                            //MessageBox.Show($"GET READY TO DRAW {numberOfLines} TIMES");


                            for (int counter = 0; counter < numberOfLines; counter++)
                            {

                                welcomeMessage = await reader.ReadLineAsync();
                                //MessageBox.Show($"X of {counter}: {welcomeMessage}");

                                xToDraw = int.Parse(welcomeMessage);

                                welcomeMessage = await reader.ReadLineAsync();
                                //MessageBox.Show($"Y of {counter}: {welcomeMessage}");

                                yToDraw = int.Parse(welcomeMessage);

                                EtchLine(xToDraw, yToDraw);

                            }

                        }
                        else if (passedX == "CLEAR")
                        {

                            EtchASketch.Clear(Color.White);
                            x = 200;
                            y = 200;

                        }

                    }
                }

                connectionOK = true;

            }
            catch (Exception ex)
            {
                
                
                MessageBox.Show($"Error: {ex.Message}");
                if (passedDirection.Contains("UP"))
                {

                     y += step;

                }
                else if (passedDirection.Contains("DOWN"))
                {

                    y -= step;

                }
                else if (passedDirection.Contains("LEFT"))
                {

                    x += step;

                }
                else if (passedDirection.Contains("RIGHT"))
                {

                    x -= step;

                }
            }

            

        }


        private static void EtchLine (int length, int width)
        {

            EtchASketch.DrawLine(pen, x, y, length, width);
            x = length;
            y = width;
        }

        private void btnUp_Click(object sender, EventArgs e)
        {

           
            try
            {

                string serverIp = txtIP.Text;
                if (string.IsNullOrEmpty(serverIp)) serverIp = "127.0.0.1";

                string serverPort = txtPort.Text;
                int port = string.IsNullOrEmpty(serverPort) ? 5000 : int.Parse(serverPort);

                string lineLength = txtLineLength.Text;
                step = string.IsNullOrEmpty(lineLength) ? 20 : int.Parse(lineLength);                

                y -= step;

                xToSend = x.ToString();
                yToSend = y.ToString();

                connectToServer(serverIp, port, xToSend, yToSend, "UP");

                
                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
                

            }

            
           
        }

        private void btnRight_Click(object sender, EventArgs e)
        {



            try
            {

                string serverIp = txtIP.Text;
                if (string.IsNullOrEmpty(serverIp)) serverIp = "127.0.0.1";

                string serverPort = txtPort.Text;
                int port = string.IsNullOrEmpty(serverPort) ? 5000 : int.Parse(serverPort);

                string lineLength = txtLineLength.Text;
                step = string.IsNullOrEmpty(lineLength) ? 20 : int.Parse(lineLength);

                x += step;

                xToSend = x.ToString();
                yToSend = y.ToString();

                connectToServer(serverIp, port, xToSend, yToSend, "RIGHT");

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());

            }
           
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            

            try
            {

                string serverIp = txtIP.Text;
                if (string.IsNullOrEmpty(serverIp)) serverIp = "127.0.0.1";

                string serverPort = txtPort.Text;
                int port = string.IsNullOrEmpty(serverPort) ? 5000 : int.Parse(serverPort);

                string lineLength = txtLineLength.Text;
                step = string.IsNullOrEmpty(lineLength) ? 20 : int.Parse(lineLength);

                y += step;

                xToSend = x.ToString();
                yToSend = y.ToString();

                connectToServer(serverIp, port, xToSend, yToSend, "DOWN");

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());

            }
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {

            

            try
            {

                string serverIp = txtIP.Text;
                if (string.IsNullOrEmpty(serverIp)) serverIp = "127.0.0.1";

                string serverPort = txtPort.Text;
                int port = string.IsNullOrEmpty(serverPort) ? 5000 : int.Parse(serverPort);

                

                connectToServer(serverIp, port, "CLEAR", "CLEAR", "No Direction");

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());

            }
            
        }

        private void rbtnBlack_CheckedChanged(object sender, EventArgs e)
        {
            pen.Color = Color.Black;
        }

        private void rbtnBlue_CheckedChanged(object sender, EventArgs e)
        {
            pen.Color = Color.Blue;
        }

        private void rbtnRed_CheckedChanged(object sender, EventArgs e)
        {
            pen.Color = Color.Red;
        }

        private void rbtnGreen_CheckedChanged(object sender, EventArgs e)
        {
            pen.Color = Color.Green;
        }

        private void rbtnYellow_CheckedChanged(object sender, EventArgs e)
        {
            pen.Color = Color.Yellow;
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {

            try
            {

                string serverIp = txtIP.Text;
                if (string.IsNullOrEmpty(serverIp)) serverIp = "127.0.0.1";

                string serverPort = txtPort.Text;
                int port = string.IsNullOrEmpty(serverPort) ? 5000 : int.Parse(serverPort);

                string lineLength = txtLineLength.Text;
                step = string.IsNullOrEmpty(lineLength) ? 20 : int.Parse(lineLength);


                x -= step;

                xToSend = x.ToString();
                yToSend = y.ToString();

                connectToServer(serverIp, port, xToSend, yToSend, "LEFT");

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());

            }
            
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {

            //pen.Color = Color.Blue;

            try
            {

                string serverIp = txtIP.Text;
                if (string.IsNullOrEmpty(serverIp)) serverIp = "127.0.0.1";

                string serverPort = txtPort.Text;
                int port = string.IsNullOrEmpty(serverPort) ? 5000 : int.Parse(serverPort);

                x = 200;
                y = 200;

                connectToServer(serverIp, port, "DRAW", "DRAW", "No Direction");

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());

            }
            




        }
    }
}
